import React from "react";
import { cn } from "@/lib/utils";

const Label = React.forwardRef(({ className, ...props }, ref) => (
  <label
    ref={ref}
    className={cn("text-sm font-medium text-slate-700 mb-1 block", className)}
    {...props}
  />
));
Label.displayName = "Label";

export { Label };
export default Label;
